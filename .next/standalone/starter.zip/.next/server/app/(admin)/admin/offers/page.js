(()=>{var e={};e.id=9995,e.ids=[9995],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},12781:e=>{"use strict";e.exports=require("stream")},73837:e=>{"use strict";e.exports=require("util")},11805:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>l.a,__next_app__:()=>u,originalPathname:()=>p,pages:()=>c,routeModule:()=>m,tree:()=>d});var r=a(50482),s=a(69108),i=a(62563),l=a.n(i),o=a(68300),n={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>o[e]);a.d(t,n);let d=["",{children:["(admin)",{children:["admin",{children:["offers",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,62824)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\admin\\offers\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,90397)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,21342)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}],c=["C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\admin\\offers\\page.tsx"],p="/(admin)/admin/offers/page",u={require:a,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/(admin)/admin/offers/page",pathname:"/admin/offers",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},24516:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,2583,23)),Promise.resolve().then(a.t.bind(a,26840,23)),Promise.resolve().then(a.t.bind(a,38771,23)),Promise.resolve().then(a.t.bind(a,13225,23)),Promise.resolve().then(a.t.bind(a,9295,23)),Promise.resolve().then(a.t.bind(a,43982,23))},95319:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,61476,23))},45136:(e,t,a)=>{Promise.resolve().then(a.bind(a,34755))},73714:(e,t,a)=>{Promise.resolve().then(a.bind(a,65029))},73098:(e,t,a)=>{"use strict";a.d(t,{Z:()=>l});var r=a(3729),s={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),l=(e,t)=>{let a=(0,r.forwardRef)(({color:a="currentColor",size:l=24,strokeWidth:o=2,absoluteStrokeWidth:n,className:d="",children:c,...p},u)=>(0,r.createElement)("svg",{ref:u,...s,width:l,height:l,stroke:a,strokeWidth:n?24*Number(o)/Number(l):o,className:["lucide",`lucide-${i(e)}`,d].join(" "),...p},[...t.map(([e,t])=>(0,r.createElement)(e,t)),...Array.isArray(c)?c:[c]]));return a.displayName=`${e}`,a}},78638:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]])},55794:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},62312:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]])},1960:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]])},48411:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]])},53148:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},56389:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},26075:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Pen",[["path",{d:"M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",key:"5qss01"}]])},24576:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Percent",[["line",{x1:"19",x2:"5",y1:"5",y2:"19",key:"1x9vlm"}],["circle",{cx:"6.5",cy:"6.5",r:"2.5",key:"4mh3h7"}],["circle",{cx:"17.5",cy:"17.5",r:"2.5",key:"1mdrzq"}]])},51838:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},76755:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]])},36341:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Tag",[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",key:"vktsd0"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor",key:"kqv944"}]])},49970:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("ToggleLeft",[["rect",{width:"20",height:"12",x:"2",y:"6",rx:"6",ry:"6",key:"f2vt7d"}],["circle",{cx:"8",cy:"12",r:"2",key:"1nvbw3"}]])},99805:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("ToggleRight",[["rect",{width:"20",height:"12",x:"2",y:"6",rx:"6",ry:"6",key:"f2vt7d"}],["circle",{cx:"16",cy:"12",r:"2",key:"4ma0v8"}]])},38271:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},65029:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>k});var r=a(95344),s=a(3729),i=a(51838),l=a(56389),o=a(36341),n=a(62312),d=a(1960),c=a(24576),p=a(48411),u=a(55794),m=a(78638),h=a(53148),x=a(76755),g=a(99805),y=a(49970),f=a(26075),b=a(38271),v=a(44669);function k(){let[e,t]=(0,s.useState)([]),[a,k]=(0,s.useState)([]),[j,w]=(0,s.useState)(!0),[N,Z]=(0,s.useState)(!1),[C,A]=(0,s.useState)(null),[M,P]=(0,s.useState)("all"),[S,z]=(0,s.useState)(null),[O,T]=(0,s.useState)({code:"",title:"",description:"",discountType:"percentage",discountValue:10,minBookingAmount:0,maxDiscountAmount:0,validFrom:new Date().toISOString().split("T")[0],validUntil:new Date(Date.now()+2592e6).toISOString().split("T")[0],usageLimit:0,isActive:!0,isPublic:!1,showOnHome:!1,applicableHotels:[]});(0,s.useEffect)(()=>{_(),H()},[M]);let _=async()=>{try{w(!0);let e=await fetch(`/api/admin/offers?scope=all&status=${"all"===M?"":M}`),a=await e.json();t(a.offers||[])}catch(e){v.Am.error("Failed to load offers")}finally{w(!1)}},H=async()=>{try{let e=await fetch("/api/admin/hotels?limit=100"),t=await e.json();k(t.hotels||[])}catch(e){console.error("Failed to load hotels")}},$=async e=>{e.preventDefault();let t=C?`/api/admin/offers/${C._id}`:"/api/admin/offers";try{let e=await fetch(t,{method:C?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(O)}),a=await e.json();if(!e.ok)throw Error(a.error||"Operation failed");v.Am.success(C?"Offer updated!":"Offer created!"),L(),_()}catch(e){v.Am.error(e.message||"Something went wrong")}},D=async e=>{if(confirm("Are you sure you want to delete this offer?"))try{await fetch(`/api/admin/offers/${e}`,{method:"DELETE"}),v.Am.success("Offer deleted"),_()}catch(e){v.Am.error("Failed to delete offer")}},q=async e=>{try{await fetch(`/api/admin/offers/${e._id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({isActive:!e.isActive})}),v.Am.success(e.isActive?"Offer deactivated":"Offer activated"),_()}catch(e){v.Am.error("Failed to update offer")}},L=()=>{Z(!1),A(null),T({code:"",title:"",description:"",discountType:"percentage",discountValue:10,minBookingAmount:0,maxDiscountAmount:0,validFrom:new Date().toISOString().split("T")[0],validUntil:new Date(Date.now()+2592e6).toISOString().split("T")[0],usageLimit:0,isActive:!0,isPublic:!1,showOnHome:!1,applicableHotels:[]})},U=e=>{A(e),T({code:e.code,title:e.title,description:e.description||"",discountType:e.discountType,discountValue:e.discountValue,minBookingAmount:e.minBookingAmount||0,maxDiscountAmount:e.maxDiscountAmount||0,validFrom:new Date(e.validFrom).toISOString().split("T")[0],validUntil:new Date(e.validUntil).toISOString().split("T")[0],usageLimit:e.usageLimit||0,isActive:e.isActive,isPublic:e.isPublic||!1,showOnHome:e.showOnHome||!1,applicableHotels:e.applicableHotels?.map(e=>e._id)||[]}),Z(!0)},E=e=>{navigator.clipboard.writeText(e),z(e),setTimeout(()=>z(null),2e3)},F=e=>new Date(e)<new Date;return(0,r.jsxs)("div",{className:"p-8 max-w-7xl mx-auto",children:[(0,r.jsxs)("div",{className:"flex justify-between items-center mb-8",children:[(0,r.jsxs)("div",{children:[r.jsx("h1",{className:"text-3xl font-bold text-gray-900",children:"Offers & Coupons"}),r.jsx("p",{className:"text-gray-500",children:"Manage platform-wide discount offers"})]}),(0,r.jsxs)("button",{onClick:()=>{A(null),L(),Z(!0)},className:"flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 font-medium",children:[r.jsx(i.Z,{size:20})," Create Offer"]})]}),r.jsx("div",{className:"flex gap-2 mb-6",children:["all","active","expired","inactive"].map(e=>r.jsx("button",{onClick:()=>P(e),className:`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${M===e?"bg-purple-600 text-white":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`,children:e.charAt(0).toUpperCase()+e.slice(1)},e))}),j?r.jsx("div",{className:"flex justify-center p-12",children:r.jsx(l.Z,{className:"animate-spin text-gray-400"})}):0===e.length?(0,r.jsxs)("div",{className:"text-center py-20 bg-gray-50 rounded-xl",children:[r.jsx(o.Z,{className:"h-12 w-12 text-gray-300 mx-auto mb-4"}),r.jsx("h3",{className:"text-xl font-bold text-gray-900 mb-2",children:"No offers yet"}),r.jsx("p",{className:"text-gray-500 mb-6",children:"Create your first coupon to get started"}),r.jsx("button",{onClick:()=>Z(!0),className:"bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700",children:"Create Offer"})]}):r.jsx("div",{className:"grid gap-4",children:e.map(e=>(0,r.jsxs)("div",{className:`bg-white border rounded-xl p-6 flex items-center gap-6 ${!e.isActive||F(e.validUntil)?"opacity-60":""}`,children:[r.jsx("div",{className:"flex-shrink-0",children:(0,r.jsxs)("button",{onClick:()=>E(e.code),className:"bg-gradient-to-r from-purple-500 to-blue-500 text-white px-4 py-3 rounded-lg font-mono font-bold text-lg flex items-center gap-2 hover:opacity-90 transition",children:[e.code,S===e.code?r.jsx(n.Z,{size:16}):r.jsx(d.Z,{size:16})]})}),(0,r.jsxs)("div",{className:"flex-grow",children:[r.jsx("h3",{className:"font-bold text-gray-900 text-lg",children:e.title}),r.jsx("p",{className:"text-gray-500 text-sm",children:e.description||"No description"}),(0,r.jsxs)("div",{className:"flex gap-4 mt-2 text-sm",children:[(0,r.jsxs)("span",{className:"flex items-center gap-1 text-purple-600",children:["percentage"===e.discountType?r.jsx(c.Z,{size:14}):r.jsx(p.Z,{size:14}),"percentage"===e.discountType?`${e.discountValue}% off`:`৳${e.discountValue} off`]}),(0,r.jsxs)("span",{className:"flex items-center gap-1 text-gray-500",children:[r.jsx(u.Z,{size:14}),"Until ",new Date(e.validUntil).toLocaleDateString()]}),(0,r.jsxs)("span",{className:"text-gray-500",children:["Used: ",e.usageCount,"/",e.usageLimit||"∞"]}),"hotel"===e.scope&&e.hotelId&&(0,r.jsxs)("span",{className:"flex items-center gap-1 text-orange-600 bg-orange-50 px-2 rounded-md",children:[r.jsx(m.Z,{size:12})," ",e.hotelId.name]})]})]}),(0,r.jsxs)("div",{className:"flex items-center gap-4",children:[F(e.validUntil)?r.jsx("span",{className:"px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold",children:"Expired"}):e.isActive?r.jsx("span",{className:"px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold",children:"Active"}):r.jsx("span",{className:"px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-bold",children:"Inactive"}),e.isPublic&&(0,r.jsxs)("span",{className:"px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold flex items-center gap-1",children:[r.jsx(h.Z,{size:12})," Public"]}),e.showOnHome&&(0,r.jsxs)("span",{className:"px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-bold flex items-center gap-1",children:[r.jsx(x.Z,{size:12})," Featured"]})]}),(0,r.jsxs)("div",{className:"flex gap-2",children:[r.jsx("button",{onClick:()=>q(e),className:`p-2 rounded-lg transition ${e.isActive?"text-green-600 hover:bg-green-50":"text-gray-400 hover:bg-gray-50"}`,title:e.isActive?"Deactivate":"Activate",children:e.isActive?r.jsx(g.Z,{size:20}):r.jsx(y.Z,{size:20})}),r.jsx("button",{onClick:()=>U(e),className:"p-2 hover:bg-gray-100 rounded-lg text-gray-500",children:r.jsx(f.Z,{size:18})}),r.jsx("button",{onClick:()=>D(e._id),className:"p-2 hover:bg-red-50 rounded-lg text-red-500",children:r.jsx(b.Z,{size:18})})]})]},e._id))}),N&&r.jsx("div",{className:"fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm",children:(0,r.jsxs)("div",{className:"bg-gray-900 border border-gray-700 rounded-xl max-w-xl w-full p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto",children:[r.jsx("h2",{className:"text-xl font-bold mb-6",children:C?"Edit Offer":"Create New Offer"}),(0,r.jsxs)("form",{onSubmit:$,className:"space-y-4",children:[(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Coupon Code *"}),r.jsx("input",{required:!0,className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white uppercase font-mono",value:O.code,onChange:e=>T({...O,code:e.target.value.toUpperCase()}),placeholder:"SUMMER25"})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Title *"}),r.jsx("input",{required:!0,className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.title,onChange:e=>T({...O,title:e.target.value}),placeholder:"Summer Sale"})]})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Description"}),r.jsx("textarea",{className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",rows:2,value:O.description,onChange:e=>T({...O,description:e.target.value}),placeholder:"Get discount on your booking..."})]}),(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Discount Type *"}),(0,r.jsxs)("select",{className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.discountType,onChange:e=>T({...O,discountType:e.target.value}),children:[r.jsx("option",{value:"percentage",children:"Percentage (%)"}),r.jsx("option",{value:"fixed",children:"Fixed Amount (৳)"})]})]}),(0,r.jsxs)("div",{children:[(0,r.jsxs)("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:["Discount Value * ","percentage"===O.discountType?"(%)":"(৳)"]}),r.jsx("input",{required:!0,type:"number",min:"1",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.discountValue,onChange:e=>T({...O,discountValue:parseInt(e.target.value)||0})})]})]}),(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Min Booking (৳)"}),r.jsx("input",{type:"number",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.minBookingAmount,onChange:e=>T({...O,minBookingAmount:parseInt(e.target.value)||0}),placeholder:"0 = No minimum"})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Max Discount (৳)"}),r.jsx("input",{type:"number",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.maxDiscountAmount,onChange:e=>T({...O,maxDiscountAmount:parseInt(e.target.value)||0}),placeholder:"0 = No cap"})]})]}),(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Valid From *"}),r.jsx("input",{required:!0,type:"date",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.validFrom,onChange:e=>T({...O,validFrom:e.target.value})})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Valid Until *"}),r.jsx("input",{required:!0,type:"date",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.validUntil,onChange:e=>T({...O,validUntil:e.target.value})})]})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Usage Limit"}),r.jsx("input",{type:"number",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white",value:O.usageLimit,onChange:e=>T({...O,usageLimit:parseInt(e.target.value)||0}),placeholder:"0 = Unlimited"}),r.jsx("p",{className:"text-xs text-gray-500 mt-1",children:"Leave 0 for unlimited uses"})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-2 text-gray-300",children:"Applicable Hotels (optional)"}),r.jsx("div",{className:"max-h-32 overflow-y-auto bg-gray-800 border border-gray-600 rounded-lg p-2",children:0===a.length?r.jsx("p",{className:"text-gray-500 text-sm",children:"Loading hotels..."}):(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("label",{className:"flex items-center gap-2 p-2 hover:bg-gray-700 rounded cursor-pointer",children:[r.jsx("input",{type:"checkbox",checked:0===O.applicableHotels.length,onChange:()=>T({...O,applicableHotels:[]}),className:"rounded"}),r.jsx("span",{className:"text-gray-300 font-medium",children:"All Hotels"})]}),a.map(e=>(0,r.jsxs)("label",{className:"flex items-center gap-2 p-2 hover:bg-gray-700 rounded cursor-pointer",children:[r.jsx("input",{type:"checkbox",checked:O.applicableHotels.includes(e._id),onChange:t=>{t.target.checked?T({...O,applicableHotels:[...O.applicableHotels,e._id]}):T({...O,applicableHotels:O.applicableHotels.filter(t=>t!==e._id)})},className:"rounded"}),r.jsx("span",{className:"text-gray-300",children:e.name})]},e._id))]})})]}),(0,r.jsxs)("div",{className:"flex gap-6 pt-2",children:[(0,r.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[r.jsx("input",{type:"checkbox",checked:O.isActive,onChange:e=>T({...O,isActive:e.target.checked}),className:"rounded"}),r.jsx("span",{className:"text-gray-300",children:"Active"})]}),(0,r.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[r.jsx("input",{type:"checkbox",checked:O.isPublic,onChange:e=>T({...O,isPublic:e.target.checked}),className:"rounded"}),r.jsx("span",{className:"text-gray-300",children:"Show on Offers Page"})]}),(0,r.jsxs)("label",{className:"flex items-center gap-2 cursor-pointer",children:[r.jsx("input",{type:"checkbox",checked:O.showOnHome,onChange:e=>T({...O,showOnHome:e.target.checked}),className:"rounded"}),r.jsx("span",{className:"text-gray-300",children:"Feature on Home"})]})]}),(0,r.jsxs)("div",{className:"flex gap-3 pt-4",children:[r.jsx("button",{type:"button",onClick:L,className:"flex-1 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-800 text-gray-300",children:"Cancel"}),(0,r.jsxs)("button",{type:"submit",className:"flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium",children:[C?"Update":"Create"," Offer"]})]})]})]})})]})}},99365:(e,t,a)=>{"use strict";a.d(t,{Z:()=>l});var r=a(40002),s={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),l=(e,t)=>{let a=(0,r.forwardRef)(({color:a="currentColor",size:l=24,strokeWidth:o=2,absoluteStrokeWidth:n,className:d="",children:c,...p},u)=>(0,r.createElement)("svg",{ref:u,...s,width:l,height:l,stroke:a,strokeWidth:n?24*Number(o)/Number(l):o,className:["lucide",`lucide-${i(e)}`,d].join(" "),...p},[...t.map(([e,t])=>(0,r.createElement)(e,t)),...Array.isArray(c)?c:[c]]));return a.displayName=`${e}`,a}},92034:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]])},21597:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]])},68631:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},29003:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},66506:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},78953:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]])},16274:(e,t,a)=>{"use strict";a.d(t,{default:()=>s.a});var r=a(48026),s=a.n(r)},48026:(e,t,a)=>{"use strict";let{createProxy:r}=a(86843);e.exports=r("C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\node_modules\\next\\dist\\client\\link.js")},62824:(e,t,a)=>{"use strict";a.r(t),a.d(t,{$$typeof:()=>i,__esModule:()=>s,default:()=>l});let r=(0,a(86843).createProxy)(String.raw`C:\Users\ismai\.gemini\antigravity\playground\primal-supernova\src\app\(admin)\admin\offers\page.tsx`),{__esModule:s,$$typeof:i}=r,l=r.default},90397:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>j});var r=a(25036),s=a(96467),i=a(867),l=a(16274),o=a(78953),n=a(92034),d=a(29003),c=a(99365);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let p=(0,c.Z)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]]),u=(0,c.Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]),m=(0,c.Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]),h=(0,c.Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);var x=a(21597);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let g=(0,c.Z)("Activity",[["path",{d:"M22 12h-4l-3 9L9 3l-3 9H2",key:"d5dnw9"}]]);var y=a(66506);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let f=(0,c.Z)("PanelsTopLeft",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]),b=(0,c.Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]),v=(0,c.Z)("Ticket",[["path",{d:"M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",key:"qn84l0"}],["path",{d:"M13 5v2",key:"dyzc3o"}],["path",{d:"M13 17v2",key:"1ont0d"}],["path",{d:"M13 11v2",key:"1wjjxi"}]]);var k=a(68631);async function j({children:e}){let t=await (0,s.ts)();t||(0,i.redirect)("/login"),"super_admin"!==t.role&&(0,i.redirect)("/vendor/dashboard");let a=[{label:"Dashboard",href:"/admin/dashboard",icon:o.Z},{label:"Hotels",href:"/admin/hotels",icon:n.Z},{label:"Destinations",href:"/admin/destinations",icon:d.Z},{label:"Templates",href:"/admin/templates",icon:p},{label:"Users",href:"/admin/users",icon:u},{label:"Plans",href:"/admin/subscriptions",icon:m},{label:"Transactions",href:"/admin/transactions",icon:h},{label:"Withdrawals",href:"/admin/withdrawals",icon:m},{label:"Domains",href:"/admin/domains",icon:x.Z},{label:"Audit Logs",href:"/admin/audit-logs",icon:g},{label:"Settings",href:"/admin/settings",icon:y.Z},{label:"Frontend",href:"/admin/frontend",icon:f},{label:"Pages",href:"/admin/pages",icon:b},{label:"Offers",href:"/admin/offers",icon:v},{label:"Bookings",href:"/admin/bookings",icon:b},{label:"Support Desk",href:"/admin/support",icon:o.Z}];return(0,r.jsxs)("div",{className:"flex min-h-screen bg-gray-900",children:[(0,r.jsxs)("aside",{className:"fixed inset-y-0 left-0 z-50 w-64 bg-gray-800 border-r border-gray-700 hidden md:flex flex-col",children:[(0,r.jsxs)("div",{className:"p-6 border-b border-gray-700 flex items-center gap-2",children:[r.jsx("div",{className:"w-8 h-8 relative",children:r.jsx("img",{src:"/logo.png",alt:"Admin Panel",className:"w-full h-full object-contain"})}),r.jsx("span",{className:"font-bold text-xl text-white",children:"Admin Panel"})]}),r.jsx("nav",{className:"flex-1 px-4 py-6 space-y-1",children:a.map(e=>(0,r.jsxs)(l.default,{href:e.href,className:"flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg text-gray-300 hover:bg-gray-700 hover:text-white transition-colors",children:[r.jsx(e.icon,{className:"h-5 w-5"}),e.label]},e.href))}),r.jsx("div",{className:"p-4 border-t border-gray-700",children:(0,r.jsxs)("div",{className:"flex items-center gap-3",children:[r.jsx("div",{className:"h-10 w-10 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold",children:"SA"}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-sm font-semibold text-white",children:"Super Admin"}),(0,r.jsxs)(l.default,{href:"/api/auth/logout",className:"text-xs text-red-400 hover:underline flex items-center gap-1",children:[r.jsx(k.Z,{className:"h-3 w-3"})," Sign Out"]})]})]})})]}),r.jsx("main",{className:"flex-1 md:ml-64 p-8 bg-gray-900 text-white",children:e})]})}},21342:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>c,metadata:()=>d});var r=a(25036),s=a(18241),i=a.n(s),l=a(91853),o=a.n(l);a(5023);var n=a(27171);let d={title:"Hotelify - Kuakata's Best Hotel Management",description:"Simplifying hospitality for Kuakata and beyond."};function c({children:e}){return r.jsx("html",{lang:"bn",children:(0,r.jsxs)("body",{className:`${i().variable} ${o().variable} font-sans bg-gray-50`,children:[e,r.jsx(n.x7,{position:"top-center"})]})})}},96467:(e,t,a)=>{"use strict";a.d(t,{WX:()=>n,setAuthCookie:()=>d,signToken:()=>o,ts:()=>c});var r=a(46082),s=a.n(r),i=a(7439);let l=process.env.JWT_SECRET||"fallback-secret-key-change-me";function o(e,t="6h"){return s().sign(e,l,{expiresIn:t})}function n(e){try{return s().verify(e,l)}catch(e){return null}}function d(e,t=21600){(0,i.cookies)().set("auth_token",e,{httpOnly:!0,secure:!0,sameSite:"lax",maxAge:t,path:"/"})}async function c(){let e=function(){let e=(0,i.cookies)();return e.get("auth_token")?.value}();return e?n(e):null}},5023:()=>{},44669:(e,t,a)=>{"use strict";a.d(t,{Am:()=>$});var r,s=a(3729);let i={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,n=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,c=(e,t)=>{let a="",r="",s="";for(let i in e){let l=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+l+";":r+="f"==i[1]?c(l,i):i+"{"+c(l,"k"==i[1]?"":t)+"}":"object"==typeof l?r+=c(l,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=l&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=c.p?c.p(i,l):i+":"+l+";")}return a+(t&&s?t+"{"+s+"}":s)+r},p={},u=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+u(e[a]);return t}return e},m=(e,t,a,r,s)=>{let i=u(e),l=p[i]||(p[i]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(i));if(!p[l]){let t=i!==e?e:(e=>{let t,a,r=[{}];for(;t=o.exec(e.replace(n,""));)t[4]?r.shift():t[3]?(a=t[3].replace(d," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(d," ").trim();return r[0]})(e);p[l]=c(s?{["@keyframes "+l]:t}:t,a?"":"."+l)}let m=a&&p.g?p.g:null;return a&&(p.g=p[l]),((e,t,a,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=a?e+t.data:t.data+e)})(p[l],t,r,m),l},h=(e,t,a)=>e.reduce((e,r,s)=>{let i=t[s];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":c(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function x(e){let t=this||{},a=e.call?e(t.p):e;return m(a.unshift?a.raw?h(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,l(t.target),t.g,t.o,t.k)}x.bind({g:1});let g,y,f,b=x.bind({k:1});function v(e,t){let a=this||{};return function(){let r=arguments;function s(i,l){let o=Object.assign({},i),n=o.className||s.className;a.p=Object.assign({theme:y&&y()},o),a.o=/ *go\d+/.test(n),o.className=x.apply(a,r)+(n?" "+n:""),t&&(o.ref=l);let d=e;return e[0]&&(d=o.as||e,delete o.as),f&&d[0]&&f(o),g(d,o)}return t?t(s):s}}var k=e=>"function"==typeof e,j=(e,t)=>k(e)?e(t):e,w=(()=>{let e=0;return()=>(++e).toString()})(),N=((()=>{let e;return()=>e})(),"default"),Z=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return Z(e,{type:e.toasts.find(e=>e.id===r.id)?1:0,toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},C=[],A={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},M={},P=(e,t=N)=>{M[t]=Z(M[t]||A,e),C.forEach(([e,a])=>{e===t&&a(M[t])})},S=e=>Object.keys(M).forEach(t=>P(e,t)),z=e=>Object.keys(M).find(t=>M[t].toasts.some(t=>t.id===e)),O=(e=N)=>t=>{P(t,e)},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},_=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||w()}),H=e=>(t,a)=>{let r=_(t,e,a);return O(r.toasterId||z(r.id))({type:2,toast:r}),r.id},$=(e,t)=>H("blank")(e,t);$.error=H("error"),$.success=H("success"),$.loading=H("loading"),$.custom=H("custom"),$.dismiss=(e,t)=>{let a={type:3,toastId:e};t?O(t)(a):S(a)},$.dismissAll=e=>$.dismiss(void 0,e),$.remove=(e,t)=>{let a={type:4,toastId:e};t?O(t)(a):S(a)},$.removeAll=e=>$.remove(void 0,e),$.promise=(e,t,a)=>{let r=$.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?j(t.success,e):void 0;return s?$.success(s,{id:r,...a,...null==a?void 0:a.success}):$.dismiss(r),e}).catch(e=>{let s=t.error?j(t.error,e):void 0;s?$.error(s,{id:r,...a,...null==a?void 0:a.error}):$.dismiss(r)}),e};var D=b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,q=b`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,L=b`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,U=(v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${D} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${q} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${L} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,b`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),E=(v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${U} 1s linear infinite;
`,b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),F=b`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,V=(v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${F} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,v("div")`
  position: absolute;
`,v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,b`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${V} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,r=s.createElement,c.p=void 0,g=r,y=void 0,f=void 0,x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[1638,7439,6082,7217,1476,867],()=>a(11805));module.exports=r})();