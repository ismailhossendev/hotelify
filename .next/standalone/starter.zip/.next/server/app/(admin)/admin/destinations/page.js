(()=>{var e={};e.id=9814,e.ids=[9814],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},12781:e=>{"use strict";e.exports=require("stream")},73837:e=>{"use strict";e.exports=require("util")},66098:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>n.a,__next_app__:()=>p,originalPathname:()=>m,pages:()=>c,routeModule:()=>u,tree:()=>d});var r=a(50482),s=a(69108),i=a(62563),n=a.n(i),o=a(68300),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);a.d(t,l);let d=["",{children:["(admin)",{children:["admin",{children:["destinations",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,89158)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\admin\\destinations\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,90397)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,21342)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,69361,23)),"next/dist/client/components/not-found-error"]}],c=["C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(admin)\\admin\\destinations\\page.tsx"],m="/(admin)/admin/destinations/page",p={require:a,loadChunk:()=>Promise.resolve()},u=new r.AppPageRouteModule({definition:{kind:s.x.APP_PAGE,page:"/(admin)/admin/destinations/page",pathname:"/admin/destinations",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},24516:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,2583,23)),Promise.resolve().then(a.t.bind(a,26840,23)),Promise.resolve().then(a.t.bind(a,38771,23)),Promise.resolve().then(a.t.bind(a,13225,23)),Promise.resolve().then(a.t.bind(a,9295,23)),Promise.resolve().then(a.t.bind(a,43982,23))},95319:(e,t,a)=>{Promise.resolve().then(a.t.bind(a,61476,23))},45136:(e,t,a)=>{Promise.resolve().then(a.bind(a,34755))},46929:(e,t,a)=>{Promise.resolve().then(a.bind(a,45923))},80508:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},26075:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Pen",[["path",{d:"M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",key:"5qss01"}]])},51838:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},76755:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]])},38271:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(73098).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},45923:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>u});var r=a(95344),s=a(3729),i=a(51838),n=a(56389),o=a(80508),l=a(76755),d=a(26075),c=a(38271),m=a(44669),p=a(62776);function u(){let[e,t]=(0,s.useState)([]),[a,u]=(0,s.useState)(!0),[h,x]=(0,s.useState)(!1),[g,f]=(0,s.useState)(null),[y,b]=(0,s.useState)({name:"",slug:"",description:"",image:"",order:0,isActive:!0,isFeatured:!1});(0,s.useEffect)(()=>{v()},[]);let v=async()=>{try{let e=await fetch("/api/admin/destinations"),a=await e.json();t(a.destinations||[])}catch(e){m.Am.error("Failed to load destinations")}finally{u(!1)}},j=async e=>{e.preventDefault();let t=g?`/api/admin/destinations/${g._id}`:"/api/admin/destinations";try{if(!(await fetch(t,{method:g?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(y)})).ok)throw Error("Operation failed");m.Am.success(g?"Updated!":"Created!"),x(!1),f(null),b({name:"",slug:"",description:"",image:"",order:0,isActive:!0,isFeatured:!1}),v()}catch(e){m.Am.error("Something went wrong")}},w=async e=>{if(confirm("Are you sure?"))try{await fetch(`/api/admin/destinations/${e}`,{method:"DELETE"}),m.Am.success("Deleted"),v()}catch(e){m.Am.error("Failed to delete")}};return(0,r.jsxs)("div",{className:"p-8 max-w-7xl mx-auto",children:[(0,r.jsxs)("div",{className:"flex justify-between items-center mb-8",children:[(0,r.jsxs)("div",{children:[r.jsx("h1",{className:"text-3xl font-bold text-gray-900",children:"Destinations"}),r.jsx("p",{className:"text-gray-500",children:"Manage locations for hotels (e.g. Cox's Bazar, Sylhet)"})]}),(0,r.jsxs)("button",{onClick:()=>{f(null),b({name:"",slug:"",description:"",image:"",order:0,isActive:!0,isFeatured:!1}),x(!0)},className:"flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700",children:[r.jsx(i.Z,{size:20})," Add Destination"]})]}),a?r.jsx("div",{className:"flex justify-center p-12",children:r.jsx(n.Z,{className:"animate-spin text-gray-400"})}):r.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:e.map(e=>(0,r.jsxs)("div",{className:"bg-white border rounded-xl p-6 shadow-sm hover:shadow-md transition",children:[(0,r.jsxs)("div",{className:"flex justify-between items-start mb-4",children:[(0,r.jsxs)("div",{className:"p-3 bg-blue-50 text-blue-600 rounded-lg relative",children:[r.jsx(o.Z,{size:24}),e.isFeatured&&r.jsx("div",{className:"absolute -top-1 -right-1 bg-yellow-400 text-yellow-900 rounded-full p-0.5",children:r.jsx(l.Z,{size:10,fill:"currentColor"})})]}),(0,r.jsxs)("div",{className:"flex gap-2",children:[r.jsx("button",{onClick:()=>{f(e),b({name:e.name,slug:e.slug,description:e.description,image:e.image||"",order:e.order,isActive:e.isActive,isFeatured:e.isFeatured||!1}),x(!0)},className:"p-2 hover:bg-gray-100 rounded-full text-gray-500",children:r.jsx(d.Z,{size:16})}),r.jsx("button",{onClick:()=>w(e._id),className:"p-2 hover:bg-red-50 rounded-full text-red-500",children:r.jsx(c.Z,{size:16})})]})]}),r.jsx("h3",{className:"font-bold text-lg text-gray-900 mb-1",children:e.name}),(0,r.jsxs)("p",{className:"text-xs text-mono text-gray-400 mb-3",children:["/",e.slug]}),r.jsx("p",{className:"text-gray-500 text-sm line-clamp-2",children:e.description||"No description provided."}),(0,r.jsxs)("div",{className:"mt-4 pt-4 border-t flex justify-between items-center",children:[(0,r.jsxs)("div",{className:"flex gap-2",children:[r.jsx("span",{className:`px-2 py-1 rounded text-xs font-bold ${e.isActive?"bg-green-100 text-green-700":"bg-gray-100 text-gray-500"}`,children:e.isActive?"Active":"Hidden"}),e.isFeatured&&(0,r.jsxs)("span",{className:"px-2 py-1 rounded text-xs font-bold bg-yellow-100 text-yellow-700 flex items-center gap-1",children:[r.jsx(l.Z,{size:10,fill:"currentColor"})," Featured"]})]}),(0,r.jsxs)("span",{className:"text-xs text-gray-400",children:["Order: ",e.order]})]})]},e._id))}),h&&r.jsx("div",{className:"fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm",children:(0,r.jsxs)("div",{className:"bg-gray-900 border border-gray-700 rounded-xl max-w-md w-full p-6 text-white shadow-2xl max-h-[90vh] overflow-y-auto",children:[r.jsx("h2",{className:"text-xl font-bold mb-6",children:g?"Edit Destination":"New Destination"}),(0,r.jsxs)("form",{onSubmit:j,className:"space-y-4",children:[(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Name"}),r.jsx("input",{required:!0,className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none",value:y.name,onChange:e=>b({...y,name:e.target.value})})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Slug (Optional)"}),r.jsx("input",{className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none",value:y.slug,onChange:e=>b({...y,slug:e.target.value}),placeholder:"Leave empty to auto-generate"})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-2 text-gray-300",children:"Destination Image"}),r.jsx("div",{className:"bg-gray-800 p-2 rounded-lg border border-gray-600",children:r.jsx(p.Z,{images:y.image?[y.image]:[],onChange:e=>b({...y,image:e[0]||""}),maxImages:1})})]}),(0,r.jsxs)("div",{children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Description"}),r.jsx("textarea",{className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none",rows:3,value:y.description,onChange:e=>b({...y,description:e.target.value})})]}),r.jsx("div",{className:"flex gap-4",children:(0,r.jsxs)("div",{className:"flex-1",children:[r.jsx("label",{className:"block text-sm font-medium mb-1 text-gray-300",children:"Sort Order"}),r.jsx("input",{type:"number",className:"w-full bg-gray-800 border border-gray-600 rounded-lg p-2 text-white focus:ring-2 focus:ring-blue-500 outline-none",value:y.order,onChange:e=>b({...y,order:parseInt(e.target.value)})})]})}),(0,r.jsxs)("div",{className:"flex justify-between gap-4 pt-2",children:[(0,r.jsxs)("div",{className:"flex items-center gap-2",children:[r.jsx("input",{type:"checkbox",id:"active",className:"w-4 h-4 rounded border-gray-600 bg-gray-800 text-blue-600 focus:ring-blue-500",checked:y.isActive,onChange:e=>b({...y,isActive:e.target.checked})}),r.jsx("label",{htmlFor:"active",className:"text-sm text-gray-300",children:"Active"})]}),(0,r.jsxs)("div",{className:"flex items-center gap-2",children:[r.jsx("input",{type:"checkbox",id:"featured",className:"w-4 h-4 rounded border-gray-600 bg-gray-800 text-yellow-500 focus:ring-yellow-500",checked:y.isFeatured,onChange:e=>b({...y,isFeatured:e.target.checked})}),(0,r.jsxs)("label",{htmlFor:"featured",className:"text-sm text-gray-300 flex items-center gap-1",children:["Featured ",r.jsx(l.Z,{className:"h-3 w-3 text-yellow-500",fill:"currentColor"})]})]})]}),(0,r.jsxs)("div",{className:"flex gap-3 pt-4",children:[r.jsx("button",{type:"button",onClick:()=>x(!1),className:"flex-1 px-4 py-2 border border-gray-600 rounded-lg hover:bg-gray-800 text-gray-300",children:"Cancel"}),r.jsx("button",{type:"submit",className:"flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium",children:"Save"})]})]})]})})]})}},62776:(e,t,a)=>{"use strict";a.d(t,{Z:()=>d});var r=a(95344),s=a(3729),i=a(14513),n=a(56389),o=a(3380),l=a(89410);function d({images:e=[],onChange:t,maxImages:a=5}){let[d,c]=(0,s.useState)(!1),m=(0,s.useRef)(null),p=async r=>{let s=r.target.files?.[0];if(s){if(e.length>=a){alert(`Maximum ${a} images allowed.`);return}c(!0);try{let a=await h(s),r=new FormData;r.append("file",a);let i=await fetch("/api/upload",{method:"POST",body:r}),n=await i.json();n.success?t([...e,n.url]):alert("Upload failed: "+n.error)}catch(e){console.error(e),alert("Upload error")}finally{c(!1),m.current&&(m.current.value="")}}},u=async(a,r)=>{confirm("Delete this image?")&&(t(e.filter((e,t)=>t!==r)),await fetch("/api/upload",{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:a})}))},h=e=>new Promise((t,a)=>{let r=new FileReader;r.readAsDataURL(e),r.onload=r=>{let s=document.createElement("img");s.src=r.target?.result,s.onload=()=>{let r=document.createElement("canvas"),i=1920/s.width,n=i<1?1920:s.width,o=i<1?s.height*i:s.height;r.width=n,r.height=o;let l=r.getContext("2d");l?.drawImage(s,0,0,n,o),r.toBlob(e=>{e?t(e):a(Error("Canvas to Blob failed"))},e.type,.8)}},r.onerror=a});return(0,r.jsxs)("div",{className:"space-y-2",children:[(0,r.jsxs)("div",{className:"flex flex-wrap gap-4",children:[e.map((e,t)=>(0,r.jsxs)("div",{className:"relative w-32 h-32 rounded-xl overflow-hidden border border-gray-200 group",children:[r.jsx(l.default,{src:e,alt:`Room ${t+1}`,fill:!0,className:"object-cover"}),r.jsx("button",{type:"button",onClick:()=>u(e,t),className:"absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity",children:r.jsx(i.Z,{className:"h-3 w-3"})})]},t)),e.length<a&&(0,r.jsxs)("div",{onClick:()=>m.current?.click(),className:"w-32 h-32 rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 hover:border-blue-400 transition-colors text-gray-400 hover:text-blue-500",children:[d?r.jsx(n.Z,{className:"h-6 w-6 animate-spin"}):(0,r.jsxs)(r.Fragment,{children:[r.jsx(o.Z,{className:"h-6 w-6 mb-1"}),r.jsx("span",{className:"text-xs font-bold",children:"Upload"})]}),r.jsx("input",{ref:m,type:"file",accept:"image/*",className:"hidden",onChange:p})]})]}),(0,r.jsxs)("p",{className:"text-xs text-gray-400",children:[e.length," / ",a," images. Optimized automatically."]})]})}},92034:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]])},21597:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]])},29003:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(99365).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},89158:(e,t,a)=>{"use strict";a.r(t),a.d(t,{$$typeof:()=>i,__esModule:()=>s,default:()=>n});let r=(0,a(86843).createProxy)(String.raw`C:\Users\ismai\.gemini\antigravity\playground\primal-supernova\src\app\(admin)\admin\destinations\page.tsx`),{__esModule:s,$$typeof:i}=r,n=r.default},90397:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>w});var r=a(25036),s=a(96467),i=a(867),n=a(16274),o=a(78953),l=a(92034),d=a(29003),c=a(99365);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let m=(0,c.Z)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]]),p=(0,c.Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]),u=(0,c.Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]),h=(0,c.Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]]);var x=a(21597);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let g=(0,c.Z)("Activity",[["path",{d:"M22 12h-4l-3 9L9 3l-3 9H2",key:"d5dnw9"}]]);var f=a(66506);/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let y=(0,c.Z)("PanelsTopLeft",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]),b=(0,c.Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]),v=(0,c.Z)("Ticket",[["path",{d:"M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",key:"qn84l0"}],["path",{d:"M13 5v2",key:"dyzc3o"}],["path",{d:"M13 17v2",key:"1ont0d"}],["path",{d:"M13 11v2",key:"1wjjxi"}]]);var j=a(68631);async function w({children:e}){let t=await (0,s.ts)();t||(0,i.redirect)("/login"),"super_admin"!==t.role&&(0,i.redirect)("/vendor/dashboard");let a=[{label:"Dashboard",href:"/admin/dashboard",icon:o.Z},{label:"Hotels",href:"/admin/hotels",icon:l.Z},{label:"Destinations",href:"/admin/destinations",icon:d.Z},{label:"Templates",href:"/admin/templates",icon:m},{label:"Users",href:"/admin/users",icon:p},{label:"Plans",href:"/admin/subscriptions",icon:u},{label:"Transactions",href:"/admin/transactions",icon:h},{label:"Withdrawals",href:"/admin/withdrawals",icon:u},{label:"Domains",href:"/admin/domains",icon:x.Z},{label:"Audit Logs",href:"/admin/audit-logs",icon:g},{label:"Settings",href:"/admin/settings",icon:f.Z},{label:"Frontend",href:"/admin/frontend",icon:y},{label:"Pages",href:"/admin/pages",icon:b},{label:"Offers",href:"/admin/offers",icon:v},{label:"Bookings",href:"/admin/bookings",icon:b},{label:"Support Desk",href:"/admin/support",icon:o.Z}];return(0,r.jsxs)("div",{className:"flex min-h-screen bg-gray-900",children:[(0,r.jsxs)("aside",{className:"fixed inset-y-0 left-0 z-50 w-64 bg-gray-800 border-r border-gray-700 hidden md:flex flex-col",children:[(0,r.jsxs)("div",{className:"p-6 border-b border-gray-700 flex items-center gap-2",children:[r.jsx("div",{className:"w-8 h-8 relative",children:r.jsx("img",{src:"/logo.png",alt:"Admin Panel",className:"w-full h-full object-contain"})}),r.jsx("span",{className:"font-bold text-xl text-white",children:"Admin Panel"})]}),r.jsx("nav",{className:"flex-1 px-4 py-6 space-y-1",children:a.map(e=>(0,r.jsxs)(n.default,{href:e.href,className:"flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg text-gray-300 hover:bg-gray-700 hover:text-white transition-colors",children:[r.jsx(e.icon,{className:"h-5 w-5"}),e.label]},e.href))}),r.jsx("div",{className:"p-4 border-t border-gray-700",children:(0,r.jsxs)("div",{className:"flex items-center gap-3",children:[r.jsx("div",{className:"h-10 w-10 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold",children:"SA"}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-sm font-semibold text-white",children:"Super Admin"}),(0,r.jsxs)(n.default,{href:"/api/auth/logout",className:"text-xs text-red-400 hover:underline flex items-center gap-1",children:[r.jsx(j.Z,{className:"h-3 w-3"})," Sign Out"]})]})]})})]}),r.jsx("main",{className:"flex-1 md:ml-64 p-8 bg-gray-900 text-white",children:e})]})}},21342:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>c,metadata:()=>d});var r=a(25036),s=a(18241),i=a.n(s),n=a(91853),o=a.n(n);a(5023);var l=a(27171);let d={title:"Hotelify - Kuakata's Best Hotel Management",description:"Simplifying hospitality for Kuakata and beyond."};function c({children:e}){return r.jsx("html",{lang:"bn",children:(0,r.jsxs)("body",{className:`${i().variable} ${o().variable} font-sans bg-gray-50`,children:[e,r.jsx(l.x7,{position:"top-center"})]})})}},96467:(e,t,a)=>{"use strict";a.d(t,{WX:()=>l,setAuthCookie:()=>d,signToken:()=>o,ts:()=>c});var r=a(46082),s=a.n(r),i=a(7439);let n=process.env.JWT_SECRET||"fallback-secret-key-change-me";function o(e,t="6h"){return s().sign(e,n,{expiresIn:t})}function l(e){try{return s().verify(e,n)}catch(e){return null}}function d(e,t=21600){(0,i.cookies)().set("auth_token",e,{httpOnly:!0,secure:!0,sameSite:"lax",maxAge:t,path:"/"})}async function c(){let e=function(){let e=(0,i.cookies)();return e.get("auth_token")?.value}();return e?l(e):null}},5023:()=>{},44669:(e,t,a)=>{"use strict";a.d(t,{Am:()=>E});var r,s=a(3729);let i={data:""},n=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i},o=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,l=/\/\*[^]*?\*\/|  +/g,d=/\n+/g,c=(e,t)=>{let a="",r="",s="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?a=i+" "+n+";":r+="f"==i[1]?c(n,i):i+"{"+c(n,"k"==i[1]?"":t)+"}":"object"==typeof n?r+=c(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=c.p?c.p(i,n):i+":"+n+";")}return a+(t&&s?t+"{"+s+"}":s)+r},m={},p=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+p(e[a]);return t}return e},u=(e,t,a,r,s)=>{let i=p(e),n=m[i]||(m[i]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(i));if(!m[n]){let t=i!==e?e:(e=>{let t,a,r=[{}];for(;t=o.exec(e.replace(l,""));)t[4]?r.shift():t[3]?(a=t[3].replace(d," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(d," ").trim();return r[0]})(e);m[n]=c(s?{["@keyframes "+n]:t}:t,a?"":"."+n)}let u=a&&m.g?m.g:null;return a&&(m.g=m[n]),((e,t,a,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=a?e+t.data:t.data+e)})(m[n],t,r,u),n},h=(e,t,a)=>e.reduce((e,r,s)=>{let i=t[s];if(i&&i.call){let e=i(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":c(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function x(e){let t=this||{},a=e.call?e(t.p):e;return u(a.unshift?a.raw?h(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,n(t.target),t.g,t.o,t.k)}x.bind({g:1});let g,f,y,b=x.bind({k:1});function v(e,t){let a=this||{};return function(){let r=arguments;function s(i,n){let o=Object.assign({},i),l=o.className||s.className;a.p=Object.assign({theme:f&&f()},o),a.o=/ *go\d+/.test(l),o.className=x.apply(a,r)+(l?" "+l:""),t&&(o.ref=n);let d=e;return e[0]&&(d=o.as||e,delete o.as),y&&d[0]&&y(o),g(d,o)}return t?t(s):s}}var j=e=>"function"==typeof e,w=(e,t)=>j(e)?e(t):e,k=(()=>{let e=0;return()=>(++e).toString()})(),N=((()=>{let e;return()=>e})(),"default"),Z=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return Z(e,{type:e.toasts.find(e=>e.id===r.id)?1:0,toast:r});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},M=[],C={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},A={},P=(e,t=N)=>{A[t]=Z(A[t]||C,e),M.forEach(([e,a])=>{e===t&&a(A[t])})},_=e=>Object.keys(A).forEach(t=>P(e,t)),S=e=>Object.keys(A).find(t=>A[t].toasts.some(t=>t.id===e)),q=(e=N)=>t=>{P(t,e)},z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},F=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||k()}),$=e=>(t,a)=>{let r=F(t,e,a);return q(r.toasterId||S(r.id))({type:2,toast:r}),r.id},E=(e,t)=>$("blank")(e,t);E.error=$("error"),E.success=$("success"),E.loading=$("loading"),E.custom=$("custom"),E.dismiss=(e,t)=>{let a={type:3,toastId:e};t?q(t)(a):_(a)},E.dismissAll=e=>E.dismiss(void 0,e),E.remove=(e,t)=>{let a={type:4,toastId:e};t?q(t)(a):_(a)},E.removeAll=e=>E.remove(void 0,e),E.promise=(e,t,a)=>{let r=E.loading(t.loading,{...a,...null==a?void 0:a.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?w(t.success,e):void 0;return s?E.success(s,{id:r,...a,...null==a?void 0:a.success}):E.dismiss(r),e}).catch(e=>{let s=t.error?w(t.error,e):void 0;s?E.error(s,{id:r,...a,...null==a?void 0:a.error}):E.dismiss(r)}),e};var D=b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,O=b`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,T=b`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,U=(v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${D} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${O} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${T} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,b`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),H=(v("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${U} 1s linear infinite;
`,b`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),L=b`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,I=(v("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${H} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,v("div")`
  position: absolute;
`,v("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,b`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);v("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${I} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,v("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,v("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,r=s.createElement,c.p=void 0,g=r,f=void 0,y=void 0,x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[1638,7439,6082,7217,1476,867,9224],()=>a(66098));module.exports=r})();