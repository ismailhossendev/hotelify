(()=>{var e={};e.id=2504,e.ids=[2504],e.modules={11185:e=>{"use strict";e.exports=require("mongoose")},47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},12781:e=>{"use strict";e.exports=require("stream")},73837:e=>{"use strict";e.exports=require("util")},86779:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>u,originalPathname:()=>x,pages:()=>o,routeModule:()=>h,tree:()=>d});var r=s(50482),a=s(69108),i=s(62563),l=s.n(i),n=s(68300),c={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>n[e]);s.d(t,c);let d=["",{children:["(marketplace)",{children:["checkout",{children:["success",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,8327)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(marketplace)\\checkout\\success\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,81427)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(marketplace)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,21342)),"C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}],o=["C:\\Users\\ismai\\.gemini\\antigravity\\playground\\primal-supernova\\src\\app\\(marketplace)\\checkout\\success\\page.tsx"],x="/(marketplace)/checkout/success/page",u={require:s,loadChunk:()=>Promise.resolve()},h=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(marketplace)/checkout/success/page",pathname:"/checkout/success",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},1564:(e,t,s)=>{Promise.resolve().then(s.bind(s,21319))},60734:(e,t,s)=>{Promise.resolve().then(s.bind(s,84192)),Promise.resolve().then(s.bind(s,22041))},33037:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},55794:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},66262:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("CircleCheckBig",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},25545:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},96885:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},13592:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Facebook",[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]])},51354:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},72086:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},23632:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Instagram",[["rect",{width:"20",height:"20",x:"2",y:"2",rx:"5",ry:"5",key:"2e1cvw"}],["path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",key:"9exkf1"}],["line",{x1:"17.5",x2:"17.51",y1:"6.5",y2:"6.5",key:"r4j83e"}]])},2273:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},78416:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Linkedin",[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",key:"c2jq9f"}],["rect",{width:"4",height:"12",x:"2",y:"9",key:"mk3on5"}],["circle",{cx:"4",cy:"4",r:"2",key:"bt5ra8"}]])},48120:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},71206:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},80508:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},98200:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},40626:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]])},28765:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},36135:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]])},95576:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("Twitter",[["path",{d:"M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",key:"pff0z6"}]])},18822:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},14513:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(73098).Z)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},56506:(e,t,s)=>{"use strict";s.d(t,{default:()=>a.a});var r=s(61476),a=s.n(r)},8428:(e,t,s)=>{"use strict";var r=s(14767);s.o(r,"notFound")&&s.d(t,{notFound:function(){return r.notFound}}),s.o(r,"useParams")&&s.d(t,{useParams:function(){return r.useParams}}),s.o(r,"useRouter")&&s.d(t,{useRouter:function(){return r.useRouter}}),s.o(r,"useSearchParams")&&s.d(t,{useSearchParams:function(){return r.useSearchParams}})},21319:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>y});var r=s(95344),a=s(3729),i=s(8428),l=s(25545),n=s(66262),c=s(72086),d=s(96885),o=s(80508),x=s(55794),u=s(40626),h=s(71206),p=s(35705),m=s(56506);function y(){let e=(0,i.useSearchParams)(),t=(0,i.useRouter)(),s=e.get("bookingId"),[y,g]=(0,a.useState)(null),[f,b]=(0,a.useState)(!0);if((0,a.useEffect)(()=>{if(!s){t.push("/");return}fetch(`/api/bookings/${s}`).then(e=>e.json()).then(e=>{e.success?g(e.booking):(alert("Booking not found"),t.push("/"))}).catch(e=>{console.error(e),alert("Failed to load booking")}).finally(()=>b(!1))},[s,t]),f)return r.jsx("div",{className:"min-h-screen flex items-center justify-center bg-gray-50 text-gray-500",children:"লোডিং..."});if(!y)return null;let j="paid"!==y.paymentStatus;return r.jsx("div",{className:"min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8",children:(0,r.jsxs)("div",{className:"max-w-3xl mx-auto",children:[(0,r.jsxs)("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-6 text-center p-10",children:[r.jsx("div",{className:"flex justify-center mb-6",children:j?r.jsx("div",{className:"h-20 w-20 bg-yellow-100 rounded-full flex items-center justify-center",children:r.jsx(l.Z,{className:"h-10 w-10 text-yellow-600"})}):r.jsx("div",{className:"h-20 w-20 bg-green-100 rounded-full flex items-center justify-center",children:r.jsx(n.Z,{className:"h-10 w-10 text-green-600"})})}),r.jsx("h1",{className:"text-3xl font-bold text-gray-900 mb-2",children:j?"আপনার বুকিংটি পেন্ডিং রয়েছে!":"ধন্যবাদ! আপনার বুকিং নিশ্চিত হয়েছে।"}),r.jsx("p",{className:"text-gray-600 max-w-lg mx-auto mb-6",children:j?"আপনার বুকিং রিকোয়েস্টটি আমাদের কাছে পৌঁছেছে। আমাদের একজন প্রতিনিধি শীঘ্রই আপনার সাথে যোগাযোগ করে বুকিং কনফার্ম করবেন।":"আপনার পেমেন্ট সফল হয়েছে। আপনার বুকিং ডিটেইলস নিচে দেওয়া হলো।"}),(0,r.jsxs)("div",{className:"flex justify-center gap-3",children:[(0,r.jsxs)(m.default,{href:"/",className:"inline-flex items-center gap-2 px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors",children:[r.jsx(c.Z,{className:"h-4 w-4"})," হোম পেজ"]}),(0,r.jsxs)("button",{onClick:()=>window.print(),className:"inline-flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors",children:[r.jsx(d.Z,{className:"h-4 w-4"})," ইনভয়েস ডাউনলোড"]})]})]}),(0,r.jsxs)("div",{className:"bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden print:shadow-none print:border-0",children:[(0,r.jsxs)("div",{className:"bg-blue-600 px-8 py-6 flex justify-between items-center text-white print:bg-gray-100 print:text-black",children:[(0,r.jsxs)("div",{children:[r.jsx("h2",{className:"text-xl font-bold",children:"INVOICE"}),(0,r.jsxs)("p",{className:"text-blue-100 print:text-gray-600",children:["Booking ID: #",y.bookingNumber]})]}),(0,r.jsxs)("div",{className:"text-right",children:[r.jsx("p",{className:"font-bold text-lg",children:"Hotelify"}),r.jsx("p",{className:"text-xs text-blue-100 opacity-80 print:text-gray-600",children:"Your Perfect Stay"})]})]}),(0,r.jsxs)("div",{className:"p-8",children:[(0,r.jsxs)("div",{className:"flex flex-col md:flex-row justify-between mb-8 pb-8 border-b border-gray-100 gap-6",children:[(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"text-xs font-bold text-gray-400 uppercase tracking-wider mb-2",children:"হোটেল ডিটেইলস"}),r.jsx("h4",{className:"font-bold text-gray-900 text-lg mb-1",children:y.roomId?.name||"Hotel Room"}),(0,r.jsxs)("div",{className:"text-gray-600 text-sm flex items-start gap-2",children:[r.jsx(o.Z,{className:"h-4 w-4 mt-0.5 shrink-0"}),r.jsx("span",{children:"Cox's Bazar, Bangladesh"})]})]}),(0,r.jsxs)("div",{className:"text-left md:text-right",children:[r.jsx("h3",{className:"text-xs font-bold text-gray-400 uppercase tracking-wider mb-2",children:"গেস্ট ইনফরমেশন"}),r.jsx("p",{className:"font-bold text-gray-900",children:y.guestDetails?.name}),r.jsx("p",{className:"text-gray-600 text-sm",children:y.guestDetails?.phone}),r.jsx("p",{className:"text-gray-600 text-sm",children:y.guestDetails?.email})]})]}),(0,r.jsxs)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-6 mb-8 bg-gray-50 p-6 rounded-xl border border-gray-100",children:[(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-xs text-gray-500 mb-1",children:"চেক-ইন"}),(0,r.jsxs)("p",{className:"font-bold text-gray-900 flex items-center gap-2",children:[r.jsx(x.Z,{className:"h-4 w-4 text-blue-500"}),(0,p.WU)(new Date(y.checkIn),"dd MMM yyyy")]})]}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-xs text-gray-500 mb-1",children:"চেক-আউট"}),(0,r.jsxs)("p",{className:"font-bold text-gray-900 flex items-center gap-2",children:[r.jsx(x.Z,{className:"h-4 w-4 text-orange-500"}),(0,p.WU)(new Date(y.checkOut),"dd MMM yyyy")]})]}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-xs text-gray-500 mb-1",children:"মোট রাত"}),(0,r.jsxs)("p",{className:"font-bold text-gray-900",children:[y.nights," Nights"]})]}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"text-xs text-gray-500 mb-1",children:"গেস্ট সংখ্যা"}),(0,r.jsxs)("p",{className:"font-bold text-gray-900",children:["object"==typeof y.guests?(y.guests.adults||0)+(y.guests.children||0):y.guests," Guests"]})]})]}),(0,r.jsxs)("div",{className:"space-y-3",children:[r.jsx("h3",{className:"text-sm font-bold text-gray-900 border-b border-gray-200 pb-2 mb-4",children:"পেমেন্ট ডিটেইলস"}),(0,r.jsxs)("div",{className:"flex justify-between text-sm text-gray-600",children:[(0,r.jsxs)("span",{children:["রুম ভাড়া (",y.nights," রাত)"]}),(0,r.jsxs)("span",{children:["৳",y.pricing.subtotal?.toLocaleString()]})]}),y.pricing.discount>0&&(0,r.jsxs)("div",{className:"flex justify-between text-sm text-green-600",children:[r.jsx("span",{children:"ডিসকাউন্ট"}),(0,r.jsxs)("span",{children:["-৳",y.pricing.discount?.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"flex justify-between items-center pt-4 mt-4 border-t border-gray-200",children:[r.jsx("span",{className:"font-bold text-gray-900 text-lg",children:"মোট টাকা"}),(0,r.jsxs)("span",{className:"font-bold text-blue-600 text-xl",children:["৳",y.pricing.totalAmount?.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"mt-6 bg-blue-50 text-blue-800 text-sm p-4 rounded-lg flex items-start gap-3",children:[r.jsx("div",{className:"mt-0.5 font-bold",children:"নোট:"}),r.jsx("p",{children:j?"বুকিংটি কনফার্ম করার জন্য হোটেল কর্তৃপক্ষের সাথে যোগাযোগ রাখা হতে পারে। চেক-ইন এর সময় পেমেন্ট সম্পন্ন করতে হবে।":"আপনার পেমেন্ট সফল হয়েছে। কোন অতিরিক্ত চার্জ প্রযোজ্য নয়।"})]})]})]}),(0,r.jsxs)("div",{className:"bg-gray-50 px-8 py-6 border-t border-gray-100 text-center text-sm text-gray-500",children:[r.jsx("p",{className:"mb-2 font-medium",children:"প্রয়োজনে যোগাযোগ করুন"}),(0,r.jsxs)("div",{className:"flex justify-center gap-6",children:[(0,r.jsxs)("span",{className:"flex items-center gap-1",children:[r.jsx(u.Z,{className:"h-4 w-4"})," +880 1700 000000"]}),(0,r.jsxs)("span",{className:"flex items-center gap-1",children:[r.jsx(h.Z,{className:"h-4 w-4"})," support@hotelify.com"]})]})]})]})]})})}},8327:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>i,__esModule:()=>a,default:()=>l});let r=(0,s(86843).createProxy)(String.raw`C:\Users\ismai\.gemini\antigravity\playground\primal-supernova\src\app\(marketplace)\checkout\success\page.tsx`),{__esModule:a,$$typeof:i}=r,l=r.default},81427:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>d});var r=s(25036),a=s(96467),i=s(97175),l=s(93841),n=s(56511),c=s(88607);async function d({children:e}){let t=await (0,a.ts)(),d=null;if(t?.userId){await (0,n.default)();let{User:e}=await s.e(4666).then(s.bind(s,74666));d=await e.findById(t.userId).select("profile role email phone name")}let o=d?{...t,name:d.profile?.name||d.name,role:d.role,avatar:d.profile?.avatar}:t;await (0,n.default)();let x=await c.l.findOne().sort({updatedAt:-1}),u=x?JSON.parse(JSON.stringify(x)):null;return(0,r.jsxs)("div",{className:"min-h-screen flex flex-col",children:[r.jsx(i.ZP,{config:u,user:o}),r.jsx("main",{className:"flex-1",children:e}),r.jsx(l.ZP,{config:u})]})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[1638,7439,6082,7217,1476,4298,1022],()=>s(86779));module.exports=r})();